<?php
echo '<p>Session expired!</p>
    <button onclick="location.href = \'index.php\';" id="goHome" class="float-left submit-button" >Login page</button>';
?>
